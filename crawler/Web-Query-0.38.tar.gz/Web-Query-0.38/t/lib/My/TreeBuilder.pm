package My::TreeBuilder;
use parent qw/HTML::TreeBuilder::XPath/;
1;